/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema.pkg1;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class Problema1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double C=1.5;  
        double E=2.5;
        
        double b= C + E;
        System.out.println("La suma de 1.5 + 2.5 es" +b);
        
    }
    
}
