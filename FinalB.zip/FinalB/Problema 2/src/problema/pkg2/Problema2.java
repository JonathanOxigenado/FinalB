/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema.pkg2;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class Problema2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
       int E;
       
       System.out.println("Ingrese su Edad");
       Scanner D1 = new Scanner(System.in);
       E=D1.nextInt();
       
       String N;
       
       System.out.println("Ingrese su Nombre");
       Scanner D2 = new Scanner(System.in);
       N=D1.next();
       
       if("Jonathan".equals(N)){
       System.out.println("Bienvenido "+N);
       }else{
        System.out.println("Incorrecto");
       }
       
       
    
        
    }
    
}
