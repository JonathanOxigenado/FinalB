/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema.pkg4;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class Problema4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String A = "Buen dia";
        String B = "Buenads tardes";
        String C = "Buenas noches";
        String D = "Bienvenido";
        String E = "A casa";
        
        System.out.println(A + " " + B + " " + C + " " + D + " " + E + " ");                                                                                                                    );
    }
    
}
